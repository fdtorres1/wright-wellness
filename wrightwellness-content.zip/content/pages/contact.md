---
title: "Contact"
slug: "contact"
type: "page"
fetched: "2025-11-07"
source_url: "https://wrightwellness.me/contact"
---

### Address
1398 W. Mayfield Rd., Suite 220  
Arlington, TX 76015

### Phone/Text & Fax*
p 682-777-4325  
f 877-805-4720

### Email**
office@wrightwellness.me

Includes an embedded contact form (name, email, phone, message) and a 'thank you' confirmation.
