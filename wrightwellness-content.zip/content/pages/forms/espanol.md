---
title: "Formularios del Paciente (Español)"
slug: "espanol-forms"
type: "page"
fetched: "2025-11-07"
source_url: "https://wrightwellness.me/espanol-forms"
---

Formularios opcionales incluyen: Autorización para divulgar información, Consentimiento Informado de Telesalud, Documentación de Custodia de Menores.
