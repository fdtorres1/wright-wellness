---
title: "Alexandra (Allie) Glenn, LPC"
slug: "alexandra-glenn"
type: "team"
fetched: "2025-11-07"
source_url: "https://wrightwellness.me/alexandra-glenn"
---

Eclectic CBT/DBT skills-based approach; telehealth-only.
