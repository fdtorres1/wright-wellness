---
title: "Shelby Upton, LPC Associate"
slug: "shelby-upton-lpc-associate"
type: "team"
fetched: "2025-11-07"
source_url: "https://wrightwellness.me/shelby-upton-lpc-associate"
---

LPC Associate since 2019; experience across private practices; supervised.
