---
title: "Shirley Bravo, LMFT Associate"
slug: "shirley-bravo"
type: "team"
fetched: "2025-11-07"
source_url: "https://wrightwellness.me/shirley-bravo"
---

Bilingual LMFT Associate; EMDR/CBT; couples/families/veterans/first responders; supervised.
