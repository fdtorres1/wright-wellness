---
title: "Ernest Smith, LPC"
slug: "ernest-smith-lpc"
type: "team"
fetched: "2025-11-07"
source_url: "https://wrightwellness.me/ernest-smith-lpc"
---

Supports adolescents, young adults, elderly through grief/anxiety/depression; safe, professional, compassionate.
