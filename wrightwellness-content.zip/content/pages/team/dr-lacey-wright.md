---
title: "Dr. Lacey Wright"
slug: "dr-lacey-wright"
type: "team"
fetched: "2025-11-07"
source_url: "https://wrightwellness.me/dr-lacey-wright"
---

Licensed clinical psychologist since 2012; PsyD 2011; specialties include trauma, depression, anxiety, women’s issues; uses CBT/ACT/MI; offers walk-and-talk therapy.
