---
title: "Lyndsey Martin, LPC"
slug: "lyndsey-martin"
type: "team"
fetched: "2025-11-07"
source_url: "https://wrightwellness.me/lyndsey-martin"
---

Specialties: depression, anxiety, trauma, eating disorders, young adults; uses DBT/ACT/EMDR; telehealth-only.
