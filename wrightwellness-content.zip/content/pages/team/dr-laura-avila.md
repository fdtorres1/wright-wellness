---
title: "Dr. Laura Ávila"
slug: "dr-laura-avila"
type: "team"
fetched: "2025-11-07"
source_url: "https://wrightwellness.me/dr-laura-avila"
---

Specialized training in CPT and Prolonged Exposure for PTSD; integrated care experience; master’s in psychopharmacology.
