---
title: "Trish Garner, Billing Manager"
slug: "trish-garner-billing-manager"
type: "team"
fetched: "2025-11-07"
source_url: "https://wrightwellness.me/trish-garner-billing-manager"
---

Healthcare admin since 2014; billing specialization; compassionate, efficient support.
