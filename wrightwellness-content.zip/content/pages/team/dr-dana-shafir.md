---
title: "Dr. Dana Shafir, LPC, CHC"
slug: "dr-dana-shafir-lpc"
type: "team"
fetched: "2025-11-07"
source_url: "https://wrightwellness.me/dr-dana-shafir-lpc"
---

Doctoral-level LPC (TWU, 2005). Experience in varied settings; offers health coaching; focus on lifestyle and integrative approaches.
