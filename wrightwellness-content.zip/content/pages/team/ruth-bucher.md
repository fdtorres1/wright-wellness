---
title: "Ruth Bucher, LMT"
slug: "ruth-bucher"
type: "team"
fetched: "2025-11-07"
source_url: "https://wrightwellness.me/ruth-bucher"
---

Advanced bodywork modalities; specialties include pain, trauma recovery, neurological conditions; customized sessions.
