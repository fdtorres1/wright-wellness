---
title: "Janelle Linares, LPC"
slug: "janelle-linares"
type: "team"
fetched: "2025-11-07"
source_url: "https://wrightwellness.me/janelle-linares"
---

Bilingual LPC (EN/ES); trauma-informed since 2014 across courts, hospitals, shelters; telehealth-only; Spanish available.
