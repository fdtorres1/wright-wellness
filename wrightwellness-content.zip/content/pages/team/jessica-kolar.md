---
title: "Jessica Kolar, LPC"
slug: "jessica-kolar-lpc"
type: "team"
fetched: "2025-11-07"
source_url: "https://wrightwellness.me/jessica-kolar-lpc"
---

Works with children, adolescents, and adults; passionate about adolescent transitions; treats anxiety, depression, trauma, attachment, parenting.
