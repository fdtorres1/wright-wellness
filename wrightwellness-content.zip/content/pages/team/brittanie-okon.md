---
title: "Brittanie Okon, Office Manager & Coordinator"
slug: "brittanie-okon"
type: "team"
fetched: "2025-11-07"
source_url: "https://wrightwellness.me/brittanie-okon"
---

Admin support so clients can focus on care; with WW since 2018.
