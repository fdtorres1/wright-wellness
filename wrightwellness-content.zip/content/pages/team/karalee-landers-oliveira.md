---
title: "Karalee Landers-Oliveira, PMHNP"
slug: "karalee-landers-aprn"
type: "team"
fetched: "2025-11-07"
source_url: "https://wrightwellness.me/karalee-landers-aprn"
---

PMHNP providing med management for 13+; specialties include depression, anxiety, ADHD, sleep and mood disorders.
