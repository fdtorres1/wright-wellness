---
title: "Elisabeth Davenport, LPC Associate, CRC"
slug: "elisabeth-davenport-lpc-associate-1"
type: "team"
fetched: "2025-11-07"
source_url: "https://wrightwellness.me/elisabeth-davenport-lpc-associate-1"
---

UNT-trained; CRC; humanistic approaches; supervised by Ashley Hendricks, LPC-S.
