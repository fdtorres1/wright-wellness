---
title: "Join Our Team"
slug: "join-our-team"
type: "page"
fetched: "2025-11-07"
source_url: "https://wrightwellness.me/join-our-team"
---

Benefits: W2 status, competitive reimbursement, admin/billing support, employee massage program, consultation, Psychology Today ad reimbursement, book club, team-building. Open positions: Licensed Counselor/Therapist; Licensed Psychologist. Includes application form.
