---
title: "Services Overview"
slug: "overview"
type: "page"
fetched: "2025-11-07"
source_url: "https://wrightwellness.me/overview"
---

- **Counseling/Psychotherapy Services** — individual, couples, and family counseling.  
- **Massage Therapy Services** — therapeutic massage to support mental and physical wellness.  
- **Medication Management Services** — evaluation and ongoing management for 12+ including depression, anxiety, ADHD, insomnia, and more.
- **Health Coaching** — individual/family health coaching (food & lifestyle).
