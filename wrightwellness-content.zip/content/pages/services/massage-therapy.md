---
title: "Massage Therapy"
slug: "massage-therapy"
type: "page"
fetched: "2025-11-07"
source_url: "https://wrightwellness.me/massage-therapy"
---

Therapeutic massage services, no-tipping policy, see **Ruth Bucher** page for specialties and details.
