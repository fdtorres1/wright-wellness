---
title: "Medication Management"
slug: "medication-management"
type: "page"
fetched: "2025-11-07"
source_url: "https://wrightwellness.me/medication-management"
---

Evaluation of symptoms, conditions, and lifestyle. Recommendations include psychotherapy, exercise, nutrition, and medications. Initial evaluation then 20–30 min follow-ups. Provided by **Karalee Landers-Oliveira, APRN** (13+).
