---
title: "Servicios de Consejería (Español)"
slug: "espanol"
type: "page"
fetched: "2025-11-07"
source_url: "https://wrightwellness.me/espanol"
---

Durante su primera sesión de terapia, realizaremos una **evaluación** de sus necesidades y metas de tratamiento. A partir de eso, juntos decidiremos si continuar trabajando conjuntamente es la mejor opción.
