---
title: "Counseling Services"
slug: "counseling-services"
type: "page"
fetched: "2025-11-07"
source_url: "https://wrightwellness.me/counseling-services"
---

Rates by clinician and telehealth availability. Notes Open Path reduced-rate option. See Reduced Rate page for more details.
