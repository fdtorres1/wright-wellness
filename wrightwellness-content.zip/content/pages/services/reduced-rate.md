---
title: "Reduced Rate Services & Fees"
slug: "reduced-rate"
type: "page"
fetched: "2025-11-07"
source_url: "https://wrightwellness.me/reduced-rate"
---

Reduced rates for counseling and medication management as low as **$65 per session**. Payment due at time of service. Open Path Collective listed as an option.
