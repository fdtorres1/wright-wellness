---
title: "Assessment & Testing"
slug: "assessment"
type: "page"
fetched: "2025-11-07"
source_url: "https://wrightwellness.me/assessment"
---

Assessments offered: Cognitive/Geriatric, Intelligence, Personality, Adult ADHD, Pre-surgical/Medical, Fitness-for-Duty/Return-to-Work, Immigration Evaluations, Adult Developmental Disability.
